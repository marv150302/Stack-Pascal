<?php

    header('Access-Control-Allow-Origin: *');   

    include("config.php");

    connect("Stack-Pascal");

    $date = date("Y/m/d");

    $type = $_GET["type"];

    if ($type == "post-comment") {

        $user_ID = $_POST["user_ID"]; 

        $post_text = $_POST["text"];

        $post_ID = $_POST["post_ID"];
        
        insertQuery("
    
        INSERT INTO Comments (ID_utente, published_date, text, post_id, upvotes)

        VALUES           ('$user_ID', '$date', '$post_text', '$post_ID', 0)

        ");

        print('success');


    }else if($type == "get-comments") {

        $post_ID = $_GET["post_ID"];

        echo json_encode(getQueryArray("SELECT c.*, u.username

        FROM Comments c, User u
        
        WHERE post_id='$post_ID'
        
        AND u.ID = c.ID_utente"));

    }elseif ($type == "number_of_comments") {

        $post_ID = $_GET["post_ID"];

        $n_comments = getQueryArray("SELECT * FROM Comments WHERE post_id='$post_ID'");
        
        echo sizeof($n_comments);
        
    }elseif ($type == "comment_pubblisher") {
        
        $user_ID = $_GET["ID"]; 

        echo json_encode(getQueryArray("SELECT * FROM User WHERE ID='$user_ID'")[0]["username"]);
    }
?>
