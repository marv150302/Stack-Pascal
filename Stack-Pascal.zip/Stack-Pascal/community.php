<?php

    header('Access-Control-Allow-Origin: *');   

    include("config.php");

    connect("Stack-Pascal");

    

    $type = $_GET['type'];

    

    //

    if ($type=="create_community") {

        $date = date("Y/m/d");

        $name= $_POST["community_name"];

        $category= $_POST["community_category"];
        
        $admin = $_POST["user_ID"];

        $check_if_avalible = getQueryArray("SELECT * FROM Community WHERE name = '$name'");

            if (sizeof($check_if_avalible) != 0) {
                
                echo "error";

                return;

            }else{

                $date = date("Y/m/d");

                insertQuery("
            
                INSERT INTO Community (name, number_participant, user_admin_ID, category, date_created)

                VALUES           ('$name', '0','$admin', '$category', '$date')
            ");
            }

    }elseif ($type=="get_coommunities") {

        $data = getQueryArray("SELECT c.*, (SELECT COUNT(p.ID) FROM Post p  
        
        WHERE p.community_id = c.ID GROUP BY c.ID) as number_of_post

        FROM Community c
        ");
            
        echo json_encode($data);


        return;

    }
?>
