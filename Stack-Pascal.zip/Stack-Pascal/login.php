<?php

    header('Access-Control-Allow-Origin: *');

    include("config.php");

    connect("Stack-Pascal");

    $email = $_POST["email"];

    $password = $_POST["password"];

    if (sizeof(getQueryArray("SELECT * FROM User WHERE email='$email' AND password='$password'")) == 1) {
       
        echo "correct";

        return;
    }

    echo "error";

?>
