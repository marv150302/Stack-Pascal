<?php
// testconnessione.php

//$conn;

function connect($database_name){
 
  global $conn;
  $conn = mysqli_connect("127.0.0.1", "root", "", $database_name);

  // Controlla che la connessione sia stata stabilita correttamente
  if (($conn == false) ||  ($conn -> connect_errno)) {
    //echo "Errore in connessione a MySQL";
    exit();
  }
  //echo "Connessione stabilita con successo";
}

  function getQueryArray($sql) {

    global $conn;

    $resultset = $conn->query($sql);

    $righe = mysqli_fetch_all($resultset, MYSQLI_ASSOC);

    return $righe;
  }

  function insertQuery($sql) {

    global $conn;

    if (mysqli_query($conn, $sql)) {

      echo "you have connected succs";

      echo "New record created successfully";

    } else {

      echo "Error: " . $sql . "<br>" . mysqli_error($conn);

    }

  }

  function update($sql){

    global $conn;
    
    if (mysqli_query($conn, $sql)) {

      echo "updated correctly";

    } else {

      echo "Error: " . $sql . "<br>" . mysqli_error($conn);

    }
  }
  function deletePost($sql){
    
    global $conn;
    
    if (mysqli_query($conn, $sql)) {

      echo "delted correctly";

    } else {

      echo "Error: " . $sql . "<br>" . mysqli_error($conn);

    }
  }

  function runQuery($sql){
    
    global $conn;
    
    if (mysqli_query($conn, $sql)) {

      echo "operation successfull";

    } else {

      echo "Error: " . $sql . "<br>" . mysqli_error($conn);

    }
  }

  function js_array($array)
{
    $temp = array_map('js_str', $array);
    return '[' . implode(',', $temp) . ']';
}

  //exit();
?>
