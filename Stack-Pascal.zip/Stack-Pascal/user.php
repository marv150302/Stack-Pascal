<?php

    header('Access-Control-Allow-Origin: *');

    include("config.php");

    connect("Stack-Pascal");

    $type = $_GET["type"];
    
    if ($type == "get-id") {
       
        $email = $_POST["email"];

        $password = $_POST["password"];

        $id = getQueryArray("SELECT ID FROM User WHERE email='$email' AND password='$password'");

        print($id[0]["ID"]);        

    }elseif ($type == "get-user-profile-data") {
       
        $id = $_GET["id"];    

        $data = getQueryArray("SELECT distinct u.*, count(p.id) as number_of_post  FROM User u, Post p WHERE u.ID=$id and p.userID = $id")[0];

        echo json_encode($data);
    }elseif ($type == "get-user-posts") {

        $id = $_GET["userID"];

        $data = getQueryArray("SELECT * FROM Post WHERE userID=$id");

        echo json_encode($data);

    }elseif ($type == 'register') {
       
        $name= $_GET["name"];

        $surname= $_GET["surname"];

        $class_ = $_GET["class"];

        $email = $_GET["email"];

        $pwd = $_GET["password"];

        $course = $_GET["course"];

        //

        $check_if_avalible = getQueryArray("SELECT * FROM User WHERE email = '$email'");

        if (sizeof($check_if_avalible) != 0) {
            
            echo "error";

        }else{

            insertQuery("
        
            INSERT INTO User (name, surname, class, email, password, course)

            VALUES           ('$name', '$surname', '$class_', '$email', '$pwd', '$course')
        ");
        }
    }

    

?>
