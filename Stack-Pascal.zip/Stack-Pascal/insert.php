<?php

    header('Access-Control-Allow-Origin: *');   

    include("config.php");

    connect("Stack-Pascal");

    $name= $_GET["name"];

    $surname= $_GET["surname"];

    $class_ = $_GET["class"];

    $email = $_GET["email"];

    $pwd = $_GET["password"];

    $course = $_GET["course"];

    //

    $check_if_avalible = getQueryArray("SELECT * FROM User WHERE email = '$email'");

    if (sizeof($check_if_avalible) != 0) {
        
        echo "error";

    }else{

        insertQuery("
    
        INSERT INTO User (name, surname, class, email, password, course)

        VALUES           ('$name', '$surname', '$class_', '$email', '$pwd', '$course')
    ");
    }
?>
