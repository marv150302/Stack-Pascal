<?php

    header('Access-Control-Allow-Origin: *');

    include("config.php");

    connect("Stack-Pascal");

    $type = $_GET["type"];

    if($type=="fetch-community-data") {
        
        $comm_id = $_GET['community'];

        $data = getQueryArray("SELECT * FROM Post WHERE community_id='$comm_id' ORDER BY id DESC");

        echo json_encode($data);

        return;

    }elseif ($type == "fetch-post-data") {
        
        $data = getQueryArray("SELECT p.*, u.username,comm.name AS community_name, u.ID AS UserID, (SELECT COUNT(*) FROM Comments c WHERE c.post_id = p.ID) AS comments
        FROM Post p, User u, Community comm
        WHERE u.ID = p.userID
        AND comm.ID = p.community_id
        ORDER BY id DESC
        ");

        echo json_encode($data);

        return;

    }elseif ($type == "delete-post") {

        $postID = $_GET["postID"];
        
        deletePost("DELETE FROM Post WHERE ID='$postID'");

        return;
    }elseif ($type == "update-like") {

        $id = $_POST["id"];

        $userID = $_POST['user_id'];

        $operation = $_POST["operation"];

        $likes = getQueryArray("SELECT likes FROM Post WHERE ID='$id'");

        $likes = (int)$likes[0]["likes"];

        $like_date = date("Y/m/d");

        if ($operation == "add") {
            
            $likes+=1;

            insertQuery("
    
            INSERT INTO Likes (user_ID, post_ID, like_date)

            VALUES           ('$userID', '$id', '$like_date')
        ");

        }else if($operation== "remove"){

            $likes-=1;

            runQuery("DELETE FROM Likes WHERE post_ID='$id'");

            
        }
        update(" UPDATE Post

                    SET likes=$likes

                    WHERE ID='$id';
            ");


        
        
    }elseif ($type == "get-post-date") {

        $id = $_GET["ID"];
        
        $data = getQueryArray("SELECT likes FROM Post WHERE ID='$id'");

        echo json_encode($data);

        return;

    }elseif ($type == "get-post-username") {
       
        $table = $_GET["table"];

        $id = $_GET["ID"];

        $userId = getQueryArray("SELECT userID FROM $table WHERE ID='$id'")[0]["userID"];
        

        $username = getQueryArray("SELECT username FROM User WHERE ID='$userId'")[0]["username"];
        

        print($username);

        return;
    }elseif ($type == "post-text") {
       
        $community = $_POST['community'];

        $title = $_POST['title'];
    
        $text = $_POST['text'];
    
        $userID = $_POST['userID'];
            
        insertQuery("INSERT into Post ( userID, date, likes, title, text, community_id)

                                VALUES($userID, CURRENT_DATE(), 0, '$title', '$text', '$community')");

        return;

    }elseif ($type=="get-news-data") {
       
        $data = getQueryArray("SELECT * FROM News");

        echo json_encode($data);

        return;
    }
    elseif ($type == 'get-liked-post') {

        $userID = $_GET['user_ID'];
        
        $data = getQueryArray("SELECT * FROM Likes WHERE user_ID='$userID'");
        
        echo json_encode($data);
        
    }elseif ($type == 'search-post') {

        if (strlen($_GET['text']) == 0) {

            return;
        }
                    
        $text = explode(' ', $_GET['text']);

        $like_query = "";

        //

        for ($i=0; $i < sizeof($text); $i++) {

            if ($i == sizeof($text)-1) {
                
                $like_query .= " title LIKE  '%".$text[$i]."%'";//if we have reached the last word of the string,
                                                                //then we don't need to add the OR at the end-
            }else{

                $like_query .= " title LIKE  '%".$text[$i]."%' OR";
            }
        }


        $sql = 'SELECT p.*, u.username, u.ID AS UserID, (SELECT COUNT(*) FROM Comments c WHERE c.post_id = p.ID) AS comments FROM Post p, User u  WHERE '.$like_query . "AND u.ID = p.userID ORDER BY id DESC";//dynamically creating the query

        $data = getQueryArray($sql);
                    
                    

        //print_r(js_array($data));

        echo json_encode($data);

        //
    }

?>
