<?php


    header('Access-Control-Allow-Origin: *');  

    include("config.php");

    connect("Stack-Pascal");


    
    $user_id = $_GET['id'];
    /* $user_id = $_POST['id'] 

    $postText = $_POST['postText'] 

    $postTitle = $_POST['postText'] 

    $community = $_POST['community']     

    $file = $_POST['file']  */

    $date =  date("Y/m/d");

    $uploadDir = "img/";
    

    $postID = 0;

    $data = getQueryArray("SELECT ID FROM Post WHERE ID=(SELECT max(ID) FROM Post)");

    if (sizeof($data) >= 1) {
        
        $postID = $data[0]["ID"] + 1;
    }else{

        $postID = 0;
    }
    //$postID = getQueryArray("SELECT ID FROM Post WHERE ID=(SELECT max(ID) FROM Post)")[0]["ID"]+1;

    //we post the post on sql database
    /* insertQuery("INSERT into Post (ID, userID, date, likes, title, text, community_id)

                VALUES(NULL, '$user_id', '$date', '0', '$postTitle', '$postText', '$community')"); */

    //$postID = $_GET["postID"];

    $user_dir = $uploadDir.$user_id;

    $post_feed_dir = "img/feed_post";

    print_r($_FILES);

    
    mkdir($user_dir);

    foreach ($_FILES as $file) {

        if (UPLOAD_ERR_OK === $file['error']) {

            $fileName = basename($file['name']);

            //$ext = pathinfo($fileName, PATHINFO_EXTENSION);

            $ext = ".png";

            $name = $postID . $ext;
        
            move_uploaded_file($file['tmp_name'], $user_dir.DIRECTORY_SEPARATOR.$name);

            $copy_file = 'img/feed_post/'.$name;

            if (!copy($user_dir . "/" .  $name,$copy_file )) {

                echo "failed to copy $file...\n";

            }

            move_uploaded_file($file['tmp_name'], $post_feed_dir.DIRECTORY_SEPARATOR.$name);
        }
}
?>