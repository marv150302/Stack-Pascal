<?php

    header('Access-Control-Allow-Origin: *');   

    include("config.php");

    connect("Stack-Pascal");

    

    $type = $_GET['type'];

    

    //

    if ($type=="insert-book") {

        $uploadDir = "img/";

        $userID = $_GET["userID"];

        $user_dir = $uploadDir.$userID. '/marketplaceBooksImages/';

        $date = date("Y/m/d");

        $name= $_GET["name"];

        $price= $_GET["price"];

        $ISBN= $_GET["ISBN"];

        $phone_number= $_GET["phoneNumber"];

        $subject= $_GET["subject"];

        $book_editor= $_GET["bookEditor"];

        $condition= $_GET["condition"];

        $user_details= $_GET["userDetails"];
        
        
        
        $email = $_GET["email"];

        

        insertQuery("
            
        INSERT INTO Books (name, price, ISBN, phone_number, subject, book_editor, bookCondition, user_details, date, userID, email)

        VALUES('$name', '$price' , '$ISBN', '$phone_number' , '$subject' , '$book_editor' , '$condition' , '$user_details' , '$date' , '$userID', '$email')
        ");

        mkdir($user_dir);

        $data = getQueryArray("SELECT ID FROM Books WHERE ID=(SELECT max(ID) FROM Books)");

    if (sizeof($data) >= 1) {
        
        $postID = $data[0]["ID"] + 1;
    }else{

        $postID = 0;
    }
    //$postID = getQueryArray("SELECT ID FROM Books WHERE ID=(SELECT max(ID) FROM Post)")[0]["ID"]+1;

        foreach ($_FILES as $file) {

            if (UPLOAD_ERR_OK === $file['error']) {
    
                $fileName = basename($file['name']);
    
                //$ext = pathinfo($fileName, PATHINFO_EXTENSION);
    
                $ext = ".png";
    
                $name = $postID . $ext;
            
                move_uploaded_file($file['tmp_name'], $user_dir.DIRECTORY_SEPARATOR.$name);
    
                $copy_file = 'img/marketPlaceFeedPost/'.$name;
    
                if (!copy($user_dir . "/" .  $name,$copy_file )) {
    
                    echo "failed to copy $file...\n";
    
                }
    
                move_uploaded_file($file['tmp_name'], $post_feed_dir.DIRECTORY_SEPARATOR.$name);
            }
    }

    }
?>
